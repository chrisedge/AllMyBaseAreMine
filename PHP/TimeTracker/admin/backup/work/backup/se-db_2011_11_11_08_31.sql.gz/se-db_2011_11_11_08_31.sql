-- Status:15:2270:MP_0:se-db:php:1.24:Final Beta Backup 111120110831:5.1.57-community:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|admin|3|16384||InnoDB
-- TABLE|categories|4|16384||InnoDB
-- TABLE|delegation|2|49152||InnoDB
-- TABLE|email_exclusion|4|32768||InnoDB
-- TABLE|global_activity|25|32768||InnoDB
-- TABLE|global_vars|4|16384||InnoDB
-- TABLE|local_activity|26|49152||InnoDB
-- TABLE|managers|135|32768||InnoDB
-- TABLE|positions|4|16384||InnoDB
-- TABLE|profile|30|49152||InnoDB
-- TABLE|regions|3|16384||InnoDB
-- TABLE|roles|4|16384||InnoDB
-- TABLE|time|595|131072||InnoDB
-- TABLE|users|716|147456||InnoDB
-- TABLE|usersTmp|715|147456||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2011-11-11 08:31

--
-- Create Table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `lastIP` varchar(27) NOT NULL DEFAULT 'None',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Data for Table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`admin_id`,`users_id`,`lastIP`) VALUES ('1','18','::1');
INSERT INTO `admin` (`admin_id`,`users_id`,`lastIP`) VALUES ('2','714','::1');
INSERT INTO `admin` (`admin_id`,`users_id`,`lastIP`) VALUES ('3','36','66.129.224.36');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


--
-- Create Table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`categories_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Data for Table `categories`
--

/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`categories_id`,`category`,`isActive`) VALUES ('1','Juniper','1');
INSERT INTO `categories` (`categories_id`,`category`,`isActive`) VALUES ('2','Enterprise','1');
INSERT INTO `categories` (`categories_id`,`category`,`isActive`) VALUES ('3','Service Provider','1');
INSERT INTO `categories` (`categories_id`,`category`,`isActive`) VALUES ('4','Channel','1');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;


--
-- Create Table `delegation`
--

DROP TABLE IF EXISTS `delegation`;
CREATE TABLE `delegation` (
  `delegation_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `effective_users_id` int(11) NOT NULL,
  PRIMARY KEY (`delegation_id`),
  KEY `uid5` (`users_id`),
  KEY `uid6` (`effective_users_id`),
  CONSTRAINT `delegation_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `delegation_ibfk_2` FOREIGN KEY (`effective_users_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Data for Table `delegation`
--

/*!40000 ALTER TABLE `delegation` DISABLE KEYS */;
INSERT INTO `delegation` (`delegation_id`,`users_id`,`effective_users_id`) VALUES ('7','36','17');
INSERT INTO `delegation` (`delegation_id`,`users_id`,`effective_users_id`) VALUES ('8','714','17');
/*!40000 ALTER TABLE `delegation` ENABLE KEYS */;


--
-- Create Table `email_exclusion`
--

DROP TABLE IF EXISTS `email_exclusion`;
CREATE TABLE `email_exclusion` (
  `email_exclusion_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `reminder` tinyint(1) NOT NULL DEFAULT '1',
  `report` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`email_exclusion_id`),
  KEY `uid7` (`users_id`),
  CONSTRAINT `email_exclusion_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Data for Table `email_exclusion`
--

/*!40000 ALTER TABLE `email_exclusion` DISABLE KEYS */;
INSERT INTO `email_exclusion` (`email_exclusion_id`,`users_id`,`reminder`,`report`) VALUES ('1','18','1','1');
INSERT INTO `email_exclusion` (`email_exclusion_id`,`users_id`,`reminder`,`report`) VALUES ('2','714','1','0');
INSERT INTO `email_exclusion` (`email_exclusion_id`,`users_id`,`reminder`,`report`) VALUES ('4','17','1','0');
INSERT INTO `email_exclusion` (`email_exclusion_id`,`users_id`,`reminder`,`report`) VALUES ('5','36','1','0');
/*!40000 ALTER TABLE `email_exclusion` ENABLE KEYS */;


--
-- Create Table `global_activity`
--

DROP TABLE IF EXISTS `global_activity`;
CREATE TABLE `global_activity` (
  `global_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`global_id`),
  KEY `categories_id` (`categories_id`),
  CONSTRAINT `global_activity_ibfk_1` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`categories_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Data for Table `global_activity`
--

/*!40000 ALTER TABLE `global_activity` DISABLE KEYS */;
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('1','1','JNPR: Internal Support','(Marketing, Engineering, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('2','1','JNPR: Tech. Training ','(SE Boot Camp, Testarossa, GSC, etc)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('3','1','JNPR: Other Training ','(HR, Compliance, Soft Skills, etc.))','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('4','1','JNPR: Travel','(non-customer related travel)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('5','1','JNPR:  PTO ','(Holiday, sick day, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('6','2','ENT: Customer Facing ','(customer meetings, EBCs, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('7','2','ENT: Customer Back Office ','(customer meeting prep. RFC prep, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('8','2','ENT: Customer Lab Activities',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('9','2','ENT: Customer Travel',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('10','2','ENT: Customer Post-Sales Activities',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('11','3','SP: Customer Facing ','(customer meetings, EBCs, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('12','3','SP: Customer Back Office ','(customer meeting prep. RFC prep, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('13','3','SP: Customer Lab Activities',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('14','3','SP: Customer Travel',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('15','3','SP: Customer Post-Sales Activities',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('16','4','CHNL: Customer Facing ','(customer meetings, EBCs, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('17','4','CHNL: Customer Back Office ','(customer meeting prep. RFC prep, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('18','4','CHNL: Customer Lab Activities',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('19','4','CHNL: Customer Travel',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('20','4','CHNL: Customer Post-Sales Activities ',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('21','1','JNPR: Internal Meetings',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('22','4','CHNL: Partner Facing','(Partner meetings, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('23','4','CHNL: Partner Back Office','(Partner meeting prep, etc.)','1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('24','4','CHNL: Partner Lab Activities',NULL,'1');
INSERT INTO `global_activity` (`global_id`,`categories_id`,`description`,`comments`,`isActive`) VALUES ('25','1','JNPR: Other','Other JNPR activities not covered by any code','1');
/*!40000 ALTER TABLE `global_activity` ENABLE KEYS */;


--
-- Create Table `global_vars`
--

DROP TABLE IF EXISTS `global_vars`;
CREATE TABLE `global_vars` (
  `global_vars_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`global_vars_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Data for Table `global_vars`
--

/*!40000 ALTER TABLE `global_vars` DISABLE KEYS */;
INSERT INTO `global_vars` (`global_vars_id`,`name`,`comment`,`value`,`updatedBy`) VALUES ('1','MAX_HOURS_PER_DAY','The maximum number of hours per day that a user is allowed to input time for.','12','2');
INSERT INTO `global_vars` (`global_vars_id`,`name`,`comment`,`value`,`updatedBy`) VALUES ('2','MIN_HOURS_PER_WEEK','The minimum number of hours that a user must have entered for a week to avoid being sent a reminder email.','32','1');
INSERT INTO `global_vars` (`global_vars_id`,`name`,`comment`,`value`,`updatedBy`) VALUES ('3','TITLE','This is title displayed for every page on the site.','SE Time Tracker','1');
INSERT INTO `global_vars` (`global_vars_id`,`name`,`comment`,`value`,`updatedBy`) VALUES ('4','DELEGATION_THRESHOLD','The minimum level of POSITION that can delegate their role. If you set this to 1, all users will have the ability.','4','1');
/*!40000 ALTER TABLE `global_vars` ENABLE KEYS */;


--
-- Create Table `local_activity`
--

DROP TABLE IF EXISTS `local_activity`;
CREATE TABLE `local_activity` (
  `local_id` int(11) NOT NULL AUTO_INCREMENT,
  `global_id` int(11) DEFAULT NULL COMMENT 'Maps to a global activity.',
  `users_id` int(11) DEFAULT NULL COMMENT 'Maps to the manager that creates this local code.',
  `description` varchar(255) NOT NULL COMMENT 'Description of the local code.',
  `comments` varchar(255) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`local_id`),
  KEY `global_id` (`global_id`),
  KEY `users_id` (`users_id`),
  CONSTRAINT `global_id` FOREIGN KEY (`global_id`) REFERENCES `global_activity` (`global_id`) ON UPDATE CASCADE,
  CONSTRAINT `users_id` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Data for Table `local_activity`
--

/*!40000 ALTER TABLE `local_activity` DISABLE KEYS */;
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('16','2','17','Quarterly SE Training','Preparation for Tech Summits, Testarossa, etc.','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('17','2','17','SE Boot Camp','Preparation, support work for SE Boot Camp','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('18','1','17','SE Time Tracker','SE Time Tracker Project','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('19','2','17','RSS Project','Support for RSS Podcast Project','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('20','1','17','SE Management Meetings','Internal SE Management Meeting','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('21','10','497','Customer Training','Customer Specific Training Post Sale','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('22','6','497','Design Workshops','Detailed Customer Design Workshops','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('23','7','497','Account Planning','NNS Process Account Planning','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('24','7','36','NNS','Account Planning','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('25','7','36','NNS','Account Review','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('26','1','36','JNPR','Other Activities','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('27','1','714','Test','Test','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('28','1','68','Data Center Business Unit Support','Working on tasks associated to the data center business unit','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('29','1','68','Marketing Support','Activities associated to support of marketing efforts','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('30','1','521','SE Lab','maintenance and configuration of lab environment. Actual demo\'s should be booked to end customer activity.','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('31','6','521','Non-GB','Customer Facing','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('32','9','521','Non-GB','Customer Travel','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('33','7','521','Non-GB','Customer Back Office','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('34','8','521','Non-GB','Customer Lab Activities','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('35','10','521','Non-GB','Customer Post-Sales Activities','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('36','1','17','JTS Participation','JTS planning, participation, etc.','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('37','11','479','1-SBY2W9','Siebel ID for TELUS Wireless','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('38','6','479','1-U0ZZIC','Siebel ID for Bank of Montreal','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('39','6','479','1-PQ38T5','Siebel ID for Citigroup','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('40','6','479','1-PMDKTR','Siebel ID for Disney','1');
INSERT INTO `local_activity` (`local_id`,`global_id`,`users_id`,`description`,`comments`,`isActive`) VALUES ('41','11','479','1-TSL1KR','Siebel ID for Rackspace','1');
/*!40000 ALTER TABLE `local_activity` ENABLE KEYS */;


--
-- Create Table `managers`
--

DROP TABLE IF EXISTS `managers`;
CREATE TABLE `managers` (
  `managers_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) DEFAULT NULL,
  `name` varchar(16) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`managers_id`),
  KEY `users_id` (`users_id`),
  CONSTRAINT `managers_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;

--
-- Data for Table `managers`
--

/*!40000 ALTER TABLE `managers` DISABLE KEYS */;
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('1','3','sfoong','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('2','4','wchan','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('3','16','mkolon','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('4','17','sstevens','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('5','18','admin','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('6','30','ismail','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('7','37','subrar','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('8','38','sandeeps','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('9','39','alvin','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('10','40','mmiller','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('11','41','bkim','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('12','42','zhanglong','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('13','43','wwang','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('14','48','swoods','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('15','52','jmaxfiel','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('16','58','twang','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('17','68','dleitzel','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('18','71','psmiraglia','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('19','73','lwang','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('20','75','tacoma','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('21','82','glousteau','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('22','87','lisp','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('23','100','szhao','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('24','129','egagala','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('25','134','jaimec','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('26','146','rdickens','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('28','194','rmickey','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('29','195','cbowers','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('30','211','kevwal','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('31','214','RPROULX','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('32','223','mcornejo','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('33','224','srichardson','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('34','230','dowang','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('35','234','wwen','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('36','238','cbisson','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('37','259','troberts','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('38','263','mmessina','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('39','264','kobbie','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('40','266','caio','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('41','269','swilliam','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('42','273','erandle','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('43','274','mkremmel','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('44','292','Kdineen','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('45','312','nhenriksson','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('46','330','truban','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('47','331','jmccombe','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('48','332','rayr','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('49','333','eteece','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('50','334','rpalmer','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('51','335','sreichmeider','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('52','340','cdierks','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('53','345','aosada','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('54','353','Lguess','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('55','354','pgerry','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('56','355','oschuermann','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('57','356','jhawk','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('58','357','vtavares','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('59','358','lemaster','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('60','359','jeremy','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('61','361','evasilenko','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('62','367','pbrickner','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('63','373','regonini','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('64','376','ksakamoto','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('65','380','sugawara','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('66','386','jseitz','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('67','387','fraimon','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('68','388','rmurrell','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('69','389','bgage','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('70','390','bpavane','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('71','391','rmudd','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('72','394','temp_mgr','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('73','395','mlangdon','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('74','396','aball','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('75','397','tomv','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('76','398','rakhanna','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('77','408','jdeabreu','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('78','415','dlindner','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('79','416','jframe','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('80','454','Raghu','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('81','464','tsuyoshi','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('82','466','sinoue','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('83','468','scrocker','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('84','469','nhomma','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('85','473','nnagatak','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('86','484','obachour','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('87','489','nburke','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('88','492','uwe','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('89','493','nsiebelink','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('90','497','arowley','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('91','504','juze','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('92','505','jmcguire','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('93','507','esicard','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('94','508','fpalozza','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('95','512','tabbas','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('96','514','jscramuzzo','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('97','516','jantich','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('98','521','mmatthews','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('99','525','mrausche','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('100','527','ecowart','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('101','528','rfjaeger','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('102','530','Cucinell','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('103','531','bagueh','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('104','534','alew','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('105','537','omelwig','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('106','538','dspillane','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('107','551','kanzai','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('108','556','mpuras','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('109','557','tcampbell','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('110','558','rogrady','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('111','572','uklatt','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('112','573','Wolfgang','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('113','577','ito','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('114','578','tmori','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('115','594','gweltmaier','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('116','695','bhaynes','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('117','696','mason','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('118','697','Slafuria','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('120','699','chrism','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('121','700','Iquinn','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('122','701','tregonini','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('123','702','jmaxfield','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('124','703','ktank','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('125','704','kwatanabe','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('126','705','fberrueta','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('127','706','elibraro','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('128','707','bpope','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('129','708','alan','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('130','709','resigned','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('131','710','rmurell','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('132','711','beden','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('133','712','pcutilla','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('134','713','ycheng','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('135','36','jpost','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('136','479','sfr','1');
INSERT INTO `managers` (`managers_id`,`users_id`,`name`,`isActive`) VALUES ('140','714','stclair','1');
/*!40000 ALTER TABLE `managers` ENABLE KEYS */;


--
-- Create Table `positions`
--

DROP TABLE IF EXISTS `positions`;
CREATE TABLE `positions` (
  `positions_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NEVER CHANGE THESE! Based on this value a user is set to be a manager or not (per jpost)',
  `position` varchar(255) NOT NULL,
  PRIMARY KEY (`positions_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Data for Table `positions`
--

/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` (`positions_id`,`position`) VALUES ('1','SE');
INSERT INTO `positions` (`positions_id`,`position`) VALUES ('2','SEM');
INSERT INTO `positions` (`positions_id`,`position`) VALUES ('3','SED');
INSERT INTO `positions` (`positions_id`,`position`) VALUES ('4','SEVP');
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;


--
-- Create Table `profile`
--

DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) DEFAULT NULL,
  `localTimezone` varchar(255) DEFAULT NULL,
  `weekStart` varchar(10) DEFAULT NULL,
  `positions_id` int(11) DEFAULT NULL,
  `regions_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`profile_id`),
  KEY `users_id` (`users_id`),
  KEY `positions_id` (`positions_id`),
  CONSTRAINT `profile_ibfk_5` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`),
  CONSTRAINT `profile_ibfk_6` FOREIGN KEY (`positions_id`) REFERENCES `positions` (`positions_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Data for Table `profile`
--

/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('6','36','America/New_York','Monday','3','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('11','17','America/New_York','Monday','4','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('13','497','Europe/London','Monday','2','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('14','521','Europe/London','Monday','2','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('15','714','America/New_York','Monday','2','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('16','3','Asia/Singapore','Monday','3','3');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('17','395','America/New_York','Monday','2','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('18','615','America/New_York','Monday','1','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('19','622','Europe/London','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('20','717','Europe/Brussels','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('21','626','Europe/London','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('22','115','Asia/Kuala_Lumpur','Monday','1','3');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('23','9','Asia/Hong_Kong','Monday','1','3');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('24','366','Europe/London','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('25','68','America/Denver','Monday','2','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('26','18','America/New_York','Monday','4','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('27','595','Europe/London','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('28','543','America/Chicago','Monday','1','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('29','159','America/Virgin','Monday','1','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('30','718','America/Argentina/Buenos_Aires','Monday','1','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('31','519','Europe/London','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('32','623','Europe/London','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('33','500','Europe/London','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('34','715','Europe/London','Monday','1','2');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('35','47','Australia/Melbourne','Monday','1','3');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('36','8','Asia/Hong_Kong','Monday','1','3');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('37','2','Asia/Singapore','Sunday','1','3');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('38','479','America/New_York','Sunday','3','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('39','285','America/Los_Angeles','Monday','1','1');
INSERT INTO `profile` (`profile_id`,`users_id`,`localTimezone`,`weekStart`,`positions_id`,`regions_id`) VALUES ('40','619','Asia/Tokyo','Monday','1','3');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;


--
-- Create Table `regions`
--

DROP TABLE IF EXISTS `regions`;
CREATE TABLE `regions` (
  `regions_id` int(11) NOT NULL AUTO_INCREMENT,
  `region` varchar(255) NOT NULL,
  PRIMARY KEY (`regions_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Data for Table `regions`
--

/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` (`regions_id`,`region`) VALUES ('1','Americas');
INSERT INTO `regions` (`regions_id`,`region`) VALUES ('2','EMEA');
INSERT INTO `regions` (`regions_id`,`region`) VALUES ('3','APAC');
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;


--
-- Create Table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `roles_id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`roles_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Data for Table `roles`
--

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`roles_id`,`role`) VALUES ('1','Enterprise');
INSERT INTO `roles` (`roles_id`,`role`) VALUES ('2','Service Provider');
INSERT INTO `roles` (`roles_id`,`role`) VALUES ('3','Channel');
INSERT INTO `roles` (`roles_id`,`role`) VALUES ('4','Both (Enterprise and Service Provider)');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;


--
-- Create Table `time`
--

DROP TABLE IF EXISTS `time`;
CREATE TABLE `time` (
  `time_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `global_id` int(11) DEFAULT NULL,
  `local_id` int(11) DEFAULT NULL,
  `hours` decimal(3,1) DEFAULT NULL,
  `managers_id` int(11) NOT NULL,
  PRIMARY KEY (`time_id`),
  KEY `global_id` (`global_id`),
  KEY `users_id` (`users_id`),
  KEY `date` (`date`),
  KEY `local_id` (`local_id`),
  CONSTRAINT `time_ibfk_11` FOREIGN KEY (`local_id`) REFERENCES `local_activity` (`local_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `time_ibfk_12` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`) ON UPDATE CASCADE,
  CONSTRAINT `time_ibfk_13` FOREIGN KEY (`global_id`) REFERENCES `global_activity` (`global_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=614 DEFAULT CHARSET=latin1;

--
-- Data for Table `time`
--

/*!40000 ALTER TABLE `time` DISABLE KEYS */;
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('1','36','2011-10-03','2','16','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('2','36','2011-10-03','1',NULL,'1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('3','36','2011-10-03','1','18','5.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('4','36','2011-10-04','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('5','36','2011-10-05','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('6','36','2011-10-06','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('7','36','2011-10-07','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('8','36','2011-09-26','1','18','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('9','36','2011-09-26','1',NULL,'4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('10','36','2011-09-27','1',NULL,'2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('11','36','2011-09-27','2','16','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('12','36','2011-09-27','1','18','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('13','36','2011-09-26','2','16','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('14','36','2011-09-26','1','18','6.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('15','36','2011-09-27','1',NULL,'2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('16','36','2011-09-27','2','16','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('17','36','2011-09-27','1','18','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('18','36','2011-09-28','1',NULL,'3.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('19','36','2011-09-28','2','16','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('20','36','2011-09-28','1','18','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('21','36','2011-09-29','1',NULL,'3.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('22','36','2011-09-29','2','16','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('23','36','2011-09-29','1','18','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('24','36','2011-09-30','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('25','36','2011-09-19','1',NULL,'2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('26','36','2011-09-19','2','16','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('27','36','2011-09-19','1','18','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('28','36','2011-09-20','1','20','1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('29','36','2011-09-20','2','16','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('30','36','2011-09-20','2','17','3.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('31','36','2011-09-21','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('32','36','2011-09-22','2','16','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('33','36','2011-09-22','1','18','6.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('34','36','2011-09-23','1',NULL,'4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('35','36','2011-09-23','1','18','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('36','36','2011-09-11','4',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('37','36','2011-09-12','2',NULL,'6.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('38','36','2011-09-12','2','16','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('39','36','2011-09-13','1','20','1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('40','36','2011-09-13','1','19','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('41','36','2011-09-13','2',NULL,'5.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('42','36','2011-09-14','4',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('43','36','2011-09-15','1',NULL,'4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('44','36','2011-09-15','1','19','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('45','36','2011-09-16','2',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('46','36','2011-09-05','5',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('47','36','2011-09-06','2','16','3.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('48','36','2011-09-06','1','20','1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('49','36','2011-09-06','2','19','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('50','36','2011-09-07','4',NULL,'2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('51','36','2011-09-07','1','18','6.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('52','36','2011-09-08','1',NULL,'2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('53','36','2011-09-08','2','17','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('54','36','2011-09-08','1','18','2.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('55','36','2011-09-09','1','18','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('56','36','2011-09-09','2','16','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('57','36','2011-08-29','5',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('58','36','2011-08-30','5',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('59','36','2011-08-31','5',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('60','36','2011-09-01','5',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('61','36','2011-09-02','5',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('62','497','2011-10-03','10',NULL,'3.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('66','615','2011-10-11','12',NULL,'8.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('67','395','2011-10-03','2',NULL,'8.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('68','395','2011-10-03','21',NULL,'4.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('69','395','2011-10-04','2',NULL,'8.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('70','395','2011-10-04','21',NULL,'4.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('71','395','2011-10-05','2',NULL,'8.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('72','395','2011-10-05','21',NULL,'4.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('73','395','2011-10-06','21',NULL,'8.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('74','395','2011-10-06','4',NULL,'8.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('75','395','2011-10-07','21',NULL,'2.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('76','395','2011-10-07','11',NULL,'2.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('77','395','2011-10-07','17',NULL,'4.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('78','626','2011-10-11','7',NULL,'12.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('79','622','2011-10-03','2',NULL,'8.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('80','622','2011-10-04','17',NULL,'8.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('81','622','2011-10-04','6',NULL,'0.5','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('82','622','2011-10-05','12',NULL,'6.5','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('83','622','2011-10-06','17',NULL,'5.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('84','622','2011-10-07','17',NULL,'3.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('85','622','2011-10-07','7',NULL,'3.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('86','115','2011-08-29','5',NULL,'12.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('87','115','2011-08-30','5',NULL,'12.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('88','115','2011-08-31','5',NULL,'12.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('89','115','2011-09-01','5',NULL,'12.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('90','115','2011-09-02','5',NULL,'12.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('91','115','2011-09-05','5',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('92','115','2011-09-05','10',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('93','115','2011-09-06','7',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('94','115','2011-09-07','7',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('95','115','2011-09-08','2',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('96','115','2011-09-09','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('97','115','2011-09-09','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('98','115','2011-09-12','7',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('99','115','2011-09-13','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('100','115','2011-09-13','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('101','115','2011-09-14','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('102','115','2011-09-14','2',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('103','115','2011-09-15','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('104','115','2011-09-15','2',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('105','115','2011-09-16','5',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('106','115','2011-09-19','6',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('107','115','2011-09-19','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('108','115','2011-09-20','21',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('109','115','2011-09-20','7',NULL,'6.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('110','115','2011-09-21','8',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('111','115','2011-09-22','6',NULL,'6.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('112','115','2011-09-22','21',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('113','115','2011-09-23','2',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('114','115','2011-09-23','8',NULL,'6.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('115','115','2011-09-26','2',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('116','115','2011-09-27','16',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('117','115','2011-09-28','7',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('118','115','2011-09-29','6',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('119','115','2011-09-30','8',NULL,'7.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('120','115','2011-09-30','21',NULL,'1.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('121','115','2011-10-03','2',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('122','115','2011-10-04','7',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('123','115','2011-10-05','11',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('124','115','2011-10-06','12',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('125','115','2011-10-07','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('126','115','2011-10-07','2',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('127','366','2011-10-13','12',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('128','366','2011-10-13','2',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('129','366','2011-10-04','3',NULL,'7.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('130','366','2011-10-04','4',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('131','366','2011-10-05','3',NULL,'7.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('132','366','2011-10-05','4',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('133','366','2011-10-06','3',NULL,'7.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('134','366','2011-10-06','4',NULL,'2.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('135','366','2011-10-07','9',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('136','366','2011-10-07','6',NULL,'4.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('137','366','2011-10-07','7',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('138','68','2011-10-03','6',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('139','68','2011-10-03','11',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('140','68','2011-10-04','6',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('141','68','2011-10-04','11',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('142','68','2011-10-05','14',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('143','68','2011-10-05','11',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('144','68','2011-10-06','14',NULL,'5.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('145','68','2011-10-06','12',NULL,'3.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('146','68','2011-10-07','6',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('147','68','2011-10-07','11',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('148','595','2011-10-10','5',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('149','595','2011-10-11','4',NULL,'7.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('150','595','2011-10-11','21',NULL,'7.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('151','595','2011-10-12','9',NULL,'0.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('152','595','2011-10-12','6',NULL,'4.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('153','595','2011-10-12','6',NULL,'0.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('154','595','2011-10-12','9',NULL,'5.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('155','595','2011-10-13','6',NULL,'2.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('156','595','2011-10-13','7',NULL,'2.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('157','595','2011-10-13','1',NULL,'0.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('158','595','2011-10-14','21',NULL,'0.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('159','595','2011-10-14','7',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('160','159','2011-10-10','21',NULL,'3.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('161','159','2011-10-10','12',NULL,'3.5','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('162','159','2011-10-10','8',NULL,'1.5','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('163','159','2011-10-11','11',NULL,'4.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('164','159','2011-10-11','13',NULL,'4.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('165','159','2011-10-12','1',NULL,'1.5','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('166','159','2011-10-12','13',NULL,'3.5','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('167','159','2011-10-12','21',NULL,'3.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('168','159','2011-10-13','21',NULL,'1.5','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('169','159','2011-10-13','13',NULL,'3.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('170','159','2011-10-13','12',NULL,'4.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('171','159','2011-10-14','11',NULL,'2.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('172','159','2011-10-14','21',NULL,'2.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('173','159','2011-10-14','13',NULL,'6.0','102');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('174','115','2011-10-10','12',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('175','115','2011-10-11','12',NULL,'3.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('176','115','2011-10-11','2',NULL,'5.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('177','115','2011-10-12','11',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('178','115','2011-10-13','21',NULL,'1.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('179','115','2011-10-13','12',NULL,'7.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('180','115','2011-10-14','2',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('190','714','2011-10-07','7','25','4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('191','714','2011-10-15','1',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('192','714','2011-10-15','2',NULL,'3.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('193','714','2011-10-15','7','25','5.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('194','714','2011-10-16','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('195','714','2011-10-16','12',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('197','622','2011-10-10','22',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('198','622','2011-10-10','23',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('199','622','2011-10-11','21',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('200','622','2011-10-12','17',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('201','622','2011-10-12','23',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('202','622','2011-10-13','22',NULL,'9.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('203','622','2011-10-13','8',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('204','622','2011-10-14','23',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('205','622','2011-10-14','16',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('206','622','2011-10-14','23',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('207','718','2011-10-10','14',NULL,'8.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('208','718','2011-10-10','11',NULL,'5.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('209','718','2011-10-11','11',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('210','718','2011-10-12','11',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('211','718','2011-10-13','13',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('212','718','2011-10-14','14',NULL,'8.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('213','718','2011-10-14','12',NULL,'6.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('214','718','2011-10-03','13',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('215','718','2011-10-04','11',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('216','718','2011-10-05','11',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('217','718','2011-10-06','11',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('218','718','2011-10-07','13',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('219','718','2011-09-26','11',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('220','718','2011-09-27','11',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('221','718','2011-09-28','13',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('222','718','2011-09-29','13',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('223','718','2011-09-30','13',NULL,'9.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('224','17','2011-10-19','1',NULL,'1.0','5');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('225','17','2011-10-19','2',NULL,'2.0','5');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('226','17','2011-10-19','3',NULL,'3.0','5');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('227','17','2011-10-19','4',NULL,'4.0','5');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('228','626','2011-10-11','7',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('229','626','2011-10-12','7',NULL,'12.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('230','626','2011-10-13','7',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('231','626','2011-10-14','7',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('232','626','2011-10-17','21',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('233','626','2011-10-17','7',NULL,'4.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('234','626','2011-10-17','8',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('235','68','2011-10-10','12',NULL,'8.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('236','68','2011-10-11','6',NULL,'2.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('237','68','2011-10-11','12',NULL,'3.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('238','68','2011-10-11','3',NULL,'3.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('239','68','2011-10-12','12',NULL,'4.5','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('240','68','2011-10-12','7',NULL,'5.5','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('241','68','2011-10-13','1',NULL,'2.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('242','68','2011-10-13','21',NULL,'2.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('243','68','2011-10-13','11',NULL,'3.5','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('244','68','2011-10-14','12',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('245','68','2011-10-14','7',NULL,'4.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('246','519','2011-10-10','16',NULL,'4.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('247','519','2011-10-10','20',NULL,'3.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('248','519','2011-10-10','23',NULL,'4.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('249','519','2011-10-11','23',NULL,'1.5','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('250','519','2011-10-11','22',NULL,'8.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('251','519','2011-10-11','20',NULL,'1.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('252','519','2011-10-12','23',NULL,'4.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('253','519','2011-10-12','20',NULL,'2.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('254','519','2011-10-13','22',NULL,'8.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('255','519','2011-10-13','20',NULL,'2.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('256','519','2011-10-13','23',NULL,'2.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('257','519','2011-10-14','22',NULL,'4.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('258','519','2011-10-14','16',NULL,'2.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('259','519','2011-10-14','8',NULL,'4.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('260','595','2011-10-17','9',NULL,'5.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('261','595','2011-10-17','6',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('262','595','2011-10-18','8',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('263','595','2011-10-18','2',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('264','595','2011-10-19','7',NULL,'4.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('265','595','2011-10-19','6',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('266','595','2011-10-19','2',NULL,'1.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('267','595','2011-10-20','7',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('268','595','2011-10-20','2',NULL,'0.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('269','595','2011-10-20','6',NULL,'0.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('270','595','2011-10-21','1',NULL,'0.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('271','595','2011-10-21','7',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('272','36','2011-10-10','2','17','6.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('273','36','2011-10-10','2','16','1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('274','36','2011-10-10','1',NULL,'1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('275','36','2011-10-11','2','17','7.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('276','36','2011-10-11','1','20','1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('277','36','2011-10-12','4',NULL,'8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('278','36','2011-10-13','1','18','10.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('279','36','2011-10-14','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('280','521','2011-10-03','21',NULL,'7.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('281','521','2011-10-04','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('282','521','2011-10-04','23',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('283','521','2011-10-05','23',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('284','521','2011-10-05','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('285','521','2011-10-06','23',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('286','521','2011-10-06','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('287','521','2011-10-07','22',NULL,'7.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('288','521','2011-10-10','23',NULL,'8.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('289','521','2011-10-11','21',NULL,'8.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('290','521','2011-10-12','21',NULL,'8.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('291','521','2011-10-13','22',NULL,'8.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('292','521','2011-10-14','22',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('293','521','2011-10-14','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('294','521','2011-10-17','23',NULL,'7.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('295','521','2011-10-18','9',NULL,'1.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('296','521','2011-10-18','6',NULL,'6.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('297','521','2011-10-18','9',NULL,'1.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('298','521','2011-10-19','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('299','521','2011-10-19','17',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('300','521','2011-10-20','23',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('301','521','2011-10-20','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('302','521','2011-10-21','23',NULL,'9.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('303','395','2011-10-10','21',NULL,'5.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('304','395','2011-10-10','12',NULL,'2.5','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('305','395','2011-10-10','11',NULL,'2.5','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('306','395','2011-10-11','21',NULL,'4.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('307','395','2011-10-11','15',NULL,'2.5','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('308','395','2011-10-11','12',NULL,'2.5','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('309','395','2011-10-12','21',NULL,'4.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('310','395','2011-10-12','11',NULL,'5.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('311','395','2011-10-13','21',NULL,'2.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('312','395','2011-10-13','11',NULL,'6.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('313','395','2011-10-14','11',NULL,'8.0','123');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('314','714','2011-10-07','1',NULL,'2.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('315','714','2011-10-09','9',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('316','714','2011-10-08','5',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('317','714','2011-10-09','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('318','714','2011-10-07','10',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('319','714','2011-10-08','7',NULL,'6.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('320','115','2011-10-17','2',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('321','115','2011-10-18','12',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('322','115','2011-10-19','12',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('323','115','2011-10-20','12',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('324','115','2011-10-21','10',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('325','622','2011-10-17','21',NULL,'1.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('326','622','2011-10-17','7',NULL,'1.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('327','622','2011-10-17','17',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('328','622','2011-10-17','6','22','1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('329','622','2011-10-18','23',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('330','622','2011-10-18','7',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('331','622','2011-10-19','7',NULL,'1.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('332','622','2011-10-19','23',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('333','622','2011-10-20','6',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('334','622','2011-10-20','24',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('335','622','2011-10-20','7',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('336','622','2011-10-21','24',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('337','622','2011-10-21','6','22','1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('338','623','2011-10-24','7',NULL,'5.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('339','623','2011-10-24','10',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('340','623','2011-10-24','8',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('341','623','2011-10-17','5',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('342','623','2011-10-18','2',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('343','623','2011-10-19','2',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('344','623','2011-10-20','2',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('345','623','2011-10-21','7',NULL,'5.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('346','623','2011-10-21','10',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('347','519','2011-10-17','6',NULL,'4.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('348','519','2011-10-17','23',NULL,'4.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('349','519','2011-10-17','20',NULL,'1.5','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('350','519','2011-10-18','23',NULL,'4.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('351','519','2011-10-18','22',NULL,'1.5','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('352','519','2011-10-18','7',NULL,'3.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('353','519','2011-10-19','16',NULL,'8.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('354','519','2011-10-20','16',NULL,'8.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('355','519','2011-10-21','7',NULL,'8.0','98');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('356','159','2011-10-17','13',NULL,'8.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('357','159','2011-10-17','5',NULL,'8.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('358','159','2011-10-18','5',NULL,'8.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('359','159','2011-10-19','13',NULL,'8.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('360','159','2011-10-20','5',NULL,'8.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('361','159','2011-10-21','5',NULL,'8.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('362','718','2011-10-17','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('363','718','2011-10-18','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('364','718','2011-10-19','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('365','718','2011-10-20','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('366','718','2011-10-21','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('367','500','2011-10-25','7','23','8.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('368','500','2011-10-17','21',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('369','500','2011-10-17','2',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('370','500','2011-10-17','6',NULL,'5.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('371','500','2011-10-18','6',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('372','500','2011-10-18','6',NULL,'4.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('373','500','2011-10-18','7',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('374','500','2011-10-19','7',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('375','500','2011-10-19','2',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('376','500','2011-10-19','6',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('377','500','2011-10-20','8',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('378','500','2011-10-20','7',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('379','500','2011-10-20','7',NULL,'1.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('380','500','2011-10-21','21',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('381','500','2011-10-21','8',NULL,'2.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('382','500','2011-10-21','7',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('383','500','2011-10-10','5',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('384','500','2011-10-11','5',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('385','500','2011-10-12','21',NULL,'0.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('386','500','2011-10-12','10',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('387','500','2011-10-12','7',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('388','500','2011-10-12','6',NULL,'2.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('389','500','2011-10-13','8',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('390','500','2011-10-13','6',NULL,'5.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('391','500','2011-10-14','21',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('392','500','2011-10-14','2',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('393','500','2011-10-14','7',NULL,'5.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('394','500','2011-10-03','2',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('395','500','2011-10-03','7',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('396','500','2011-10-04','8',NULL,'3.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('397','500','2011-10-04','6',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('398','500','2011-10-04','7',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('399','500','2011-10-05','5',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('400','500','2011-10-06','5',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('401','500','2011-10-07','5',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('402','500','2011-09-26','21',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('403','500','2011-09-26','7',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('404','500','2011-09-26','10',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('405','500','2011-09-26','8',NULL,'2.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('406','500','2011-09-27','9',NULL,'1.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('407','500','2011-09-27','6',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('408','500','2011-09-27','7',NULL,'3.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('409','500','2011-09-28','8',NULL,'3.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('410','500','2011-09-28','7',NULL,'2.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('411','500','2011-09-28','6',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('412','500','2011-09-29','9',NULL,'3.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('413','500','2011-09-29','6',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('414','500','2011-09-29','9',NULL,'3.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('415','500','2011-09-30','21',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('416','500','2011-09-30','2',NULL,'3.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('417','500','2011-09-30','7',NULL,'2.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('418','715','2011-10-03','1',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('419','715','2011-10-03','21',NULL,'1.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('420','715','2011-10-03','7',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('421','715','2011-10-03','1',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('422','715','2011-10-04','7',NULL,'9.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('423','715','2011-10-05','9',NULL,'4.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('424','715','2011-10-05','6',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('425','715','2011-10-05','23',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('426','715','2011-10-06','9',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('427','715','2011-10-06','9',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('428','715','2011-10-07','21',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('429','715','2011-10-07','7',NULL,'12.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('430','715','2011-10-10','7',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('431','715','2011-10-10','23',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('432','715','2011-10-11','9',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('433','715','2011-10-11','6',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('434','715','2011-10-12','9',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('435','715','2011-10-12','6',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('436','715','2011-10-13','9',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('437','715','2011-10-13','6',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('438','715','2011-10-14','9',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('439','715','2011-10-14','6',NULL,'8.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('440','715','2011-10-17','6',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('441','715','2011-10-18','6',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('442','715','2011-10-19','6',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('443','715','2011-10-20','6',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('444','715','2011-10-21','6',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('445','3','2011-10-17','21',NULL,'4.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('446','3','2011-10-17','22',NULL,'4.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('447','3','2011-10-18','21',NULL,'4.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('448','3','2011-10-18','3',NULL,'1.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('449','3','2011-10-19','1',NULL,'3.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('450','3','2011-10-19','21',NULL,'2.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('451','3','2011-10-20','10',NULL,'1.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('452','3','2011-10-20','21',NULL,'3.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('453','3','2011-10-21','21',NULL,'4.0','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('454','3','2011-10-21','6',NULL,'1.5','80');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('455','714','2011-10-16','4',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('456','714','2011-10-17','8',NULL,'6.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('457','714','2011-10-18','7','24','5.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('458','36','2011-10-17','1','18','3.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('459','36','2011-10-17','1','20','4.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('460','36','2011-10-17','2','16','1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('461','36','2011-10-18','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('462','36','2011-10-19','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('463','36','2011-10-20','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('464','36','2011-10-21','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('465','36','2011-10-20','2','19','1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('466','36','2011-10-18','2','17','1.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('467','36','2011-10-21','1',NULL,'10.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('468','36','2011-10-24','2','16','3.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('469','36','2011-10-24','1','18','5.5','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('471','47','2011-10-27','7',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('472','47','2011-10-24','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('473','47','2011-10-24','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('474','47','2011-10-25','6',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('475','47','2011-10-26','12',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('476','47','2011-10-27','12',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('477','8','2011-10-24','1',NULL,'1.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('478','8','2011-10-24','12',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('479','8','2011-10-24','8',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('480','8','2011-10-25','1',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('481','8','2011-10-25','8',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('482','8','2011-10-25','13',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('483','8','2011-10-26','1',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('484','8','2011-10-26','21',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('485','8','2011-10-26','8',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('486','8','2011-10-27','1',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('487','8','2011-10-27','23',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('488','8','2011-10-27','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('489','8','2011-10-28','1',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('490','8','2011-10-28','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('491','8','2011-10-28','23',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('492','714','2011-10-18','6',NULL,'6.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('493','714','2011-10-22','7','25','12.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('494','36','2011-10-16','1','18','8.0','4');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('495','115','2011-10-24','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('496','115','2011-10-24','2',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('497','115','2011-10-25','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('498','115','2011-10-25','2',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('499','115','2011-10-26','2',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('500','115','2011-10-26','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('501','115','2011-10-27','2',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('502','115','2011-10-27','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('503','115','2011-10-28','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('504','115','2011-10-28','2',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('508','2','2011-10-24','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('509','2','2011-10-28','7',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('510','2','2011-10-28','8',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('511','715','2011-10-24','6',NULL,'9.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('512','715','2011-10-25','6',NULL,'9.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('513','715','2011-10-26','6',NULL,'9.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('514','715','2011-10-27','6',NULL,'9.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('515','715','2011-10-28','6',NULL,'9.5','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('516','543','2011-10-24','21',NULL,'1.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('517','543','2011-10-24','1','26','6.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('518','543','2011-10-25','21',NULL,'1.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('519','543','2011-10-25','1','26','7.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('520','543','2011-10-26','6',NULL,'8.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('521','543','2011-10-27','6',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('522','543','2011-10-27','7',NULL,'4.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('523','543','2011-10-28','7',NULL,'8.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('524','622','2011-10-24','18',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('525','622','2011-10-24','18',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('526','622','2011-10-24','17',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('527','622','2011-10-25','7',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('528','622','2011-10-25','23',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('529','622','2011-10-26','23',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('530','622','2011-10-26','24',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('531','622','2011-10-27','23',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('532','622','2011-10-27','24',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('533','622','2011-10-28','22',NULL,'1.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('534','622','2011-10-28','7',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('535','718','2011-10-24','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('536','718','2011-10-25','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('537','718','2011-10-26','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('538','718','2011-10-27','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('539','718','2011-10-28','12',NULL,'10.0','40');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('540','497','2011-10-03','21',NULL,'3.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('541','497','2011-10-03','7',NULL,'2.5','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('543','68','2011-10-16','22',NULL,'6.0','136');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('544','626','2011-10-18','2',NULL,'6.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('545','626','2011-10-18','7',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('546','626','2011-10-18','7',NULL,'2.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('547','626','2011-10-19','7',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('548','626','2011-10-20','7',NULL,'10.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('549','626','2011-10-21','9',NULL,'5.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('550','626','2011-10-21','6',NULL,'3.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('551','626','2011-10-24','5',NULL,'12.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('552','626','2011-10-25','5',NULL,'12.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('553','626','2011-10-26','5',NULL,'12.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('554','626','2011-10-27','5',NULL,'12.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('555','626','2011-10-28','5',NULL,'12.0','90');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('556','479','2011-10-03','1',NULL,'9.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('557','479','2011-10-04','1',NULL,'9.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('558','479','2011-10-05','1',NULL,'9.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('559','479','2011-10-06','1',NULL,'9.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('560','479','2011-10-07','1',NULL,'9.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('561','479','2011-10-10','11',NULL,'9.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('562','479','2011-10-11','11',NULL,'9.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('563','479','2011-10-12','11',NULL,'9.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('564','479','2011-10-13','6',NULL,'9.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('565','479','2011-10-14','6',NULL,'9.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('566','479','2011-10-17','16',NULL,'9.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('567','479','2011-10-18','14',NULL,'9.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('568','479','2011-10-19','13',NULL,'12.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('569','479','2011-10-20','12',NULL,'10.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('570','479','2011-10-21','10',NULL,'8.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('571','479','2011-10-24','13',NULL,'12.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('572','479','2011-10-25','8',NULL,'9.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('573','479','2011-10-26','9',NULL,'8.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('574','479','2011-10-27','6',NULL,'11.0','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('575','479','2011-10-28','9',NULL,'9.5','122');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('576','714','2011-10-23','5',NULL,'3.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('577','714','2011-10-23','1','26','3.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('578','714','2011-10-23','13',NULL,'3.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('579','714','2011-10-23','7',NULL,'3.0','135');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('580','285','2011-10-24','21',NULL,'5.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('581','285','2011-10-24','13',NULL,'5.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('582','285','2011-10-25','12',NULL,'5.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('583','285','2011-10-25','13',NULL,'5.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('584','285','2011-10-26','11',NULL,'9.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('585','285','2011-10-27','13',NULL,'6.5','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('586','285','2011-10-27','11',NULL,'3.5','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('587','285','2011-10-28','5',NULL,'8.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('588','285','2011-10-31','21',NULL,'4.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('589','285','2011-10-31','12',NULL,'5.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('590','285','2011-11-01','13',NULL,'9.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('591','285','2011-11-02','6',NULL,'12.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('592','285','2011-11-03','11',NULL,'12.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('593','285','2011-11-04','21',NULL,'4.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('594','285','2011-11-04','13',NULL,'6.0','20');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('595','115','2011-10-31','5',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('596','115','2011-11-01','7',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('597','115','2011-11-02','21',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('598','115','2011-11-03','21',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('599','115','2011-11-03','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('600','115','2011-11-04','2',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('601','619','2011-10-24','5',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('602','619','2011-10-25','6',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('603','619','2011-10-25','7',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('604','619','2011-10-26','12',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('605','619','2011-10-27','14',NULL,'6.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('606','619','2011-10-27','12',NULL,'2.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('607','619','2011-10-28','11',NULL,'4.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('608','619','2011-10-28','14',NULL,'6.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('609','619','2011-10-31','17',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('610','619','2011-11-01','3',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('611','619','2011-11-02','3',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('612','619','2011-11-03','5',NULL,'8.0','1');
INSERT INTO `time` (`time_id`,`users_id`,`date`,`global_id`,`local_id`,`hours`,`managers_id`) VALUES ('613','619','2011-11-04','3',NULL,'8.0','1');
/*!40000 ALTER TABLE `time` ENABLE KEYS */;


--
-- Create Table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `users_id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `password` char(32) NOT NULL DEFAULT '4c3ee0195f2444ad204ccd7d94cb6d16',
  `mgr` varchar(16) DEFAULT NULL COMMENT 'This field is for historical purposes and will be deprecated.',
  `managers_id` int(11) DEFAULT '5' COMMENT 'The default value is the admin user''s managers_id of 5. This must remain. Also, NULL must be allowed because the admin user doesn''t report to anyone.',
  `hasProfile` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Has the user defined a profile yet?',
  `passwordChange` date DEFAULT NULL,
  PRIMARY KEY (`users_id`),
  UNIQUE KEY `userName` (`userName`),
  KEY `mgr` (`mgr`),
  KEY `managers_id` (`managers_id`)
) ENGINE=InnoDB AUTO_INCREMENT=719 DEFAULT CHARSET=latin1;

--
-- Data for Table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('1','kuangbin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16',NULL,'5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('2','atham','atham@juniper.net','Adrian','Tham','09fccda1a96bae2c59d48dfd40ea2cff','sfoong','1','1','2011-10-30');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('3','sfoong','sfoong@juniper.net','Sui Jin','Foong','d8578edf8458ce06fbc5bb76a58c5ca4',NULL,'80','1','2011-10-10');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('4','wchan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('5','mkohno',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('6','hidet',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('7','bayliss',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mkolon','3','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('8','ALeung','aleung@juniper.net','Andy','Leung','df2537a3707c6df9be852f38f42aef20','sfoong','1','1','2011-10-28');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('9','kkan','kkan@juniper.net','Kondia','Kan','9fd1ead68c0329f5332d744a1524413c','sfoong','1','1','2011-10-13');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('10','harryt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan','2','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('11','henrycheung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan','2','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('12','echoi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan','2','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('13','atong',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan','2','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('14','mchen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan','2','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('15','srho',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan','2','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('16','mkolon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('17','sstevens','sstevens@juniper.net','Scott','Stevens','4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','1','2011-10-09');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('18','admin','stclair@biggiesize.com','Admin','User','e584c11797347c15adb087a5c30e34e3',NULL,NULL,'1','2011-10-13');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('19','krajesh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('20','aaronchan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ismail','6','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('21','rohits',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('22','amandhar',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('23','pbose',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('24','dane',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('25','ingack',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bkim','11','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('26','bpchoi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bkim','11','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('27','htxu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','zhanglong','12','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('28','hlyeo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('29','zhuolin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Zhanglong','12','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('30','ismail',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('31','indrajaya',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('32','mdoan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','resigned','130','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('33','tnagy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('34','jatkins',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('35','fprowse',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('36','jpost','jpost@juniper.net','Jim','Post','4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','1','2011-10-07');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('37','subrar',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('38','sandeeps',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('39','alvin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('40','mmiller',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('41','bkim',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('42','zhanglong',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('43','wwang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('44','ipalmer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('45','naveenar',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('46','aliang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','zhanglong','12','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('47','bhutson','bhutson@juniper.net','brian','hutson','8ce616a4528457663f0b263cbc5b3230','sfoong','1','1','2011-10-27');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('48','swoods',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('49','bisham',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('50','jpsingh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('51','msee',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ycheng','134','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('52','jmaxfiel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('53','zeskiocak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('54','hamish',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('55','jnavarro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','caio','40','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('56','dcsonka',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('57','shannon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('58','twang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('59','jackycj',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','twang','16','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('60','changyu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','szhao','23','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('61','wtian',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','twang','16','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('62','yzhi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','twang','16','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('63','markanderson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbowers','29','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('64','shawn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lwang','19','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('65','yuxin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lwang','19','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('66','anorton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kevwal','30','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('67','brent',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bhaynes','116','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('68','dleitzel','dleitzel@juniper.net','David','Leitzel','6f8dfae0bda9474d5e63c56bdde5e0fe','jmccombe','136','1','2011-10-20');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('69','simonmao',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Twang','16','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('70','azrahia',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('71','psmiraglia',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','regonini','63','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('72','liuj',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lwang','19','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('73','lwang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('74','pkedra',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('75','tacoma',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('76','rwhitney',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('77','pzablotski',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Slafuria','118','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('78','gfecteau',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Cucinell','102','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('79','mike',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('80','gguay',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('81','mccarthy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('82','glousteau',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('83','marco',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('84','jcoppock',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('85','tonyzeng',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','zhanglong','12','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('86','lfeinbaum',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('87','lisp',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('88','chenjiang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('89','hadlley',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('90','rpasco',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('91','sbrown',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('92','dspesard',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('93','jayd',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('94','djl',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('95','gshen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lwang','19','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('96','jasonli',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('97','mshamjee',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('98','sujit',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('99','yeht',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('100','szhao',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('101','josephk',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('102','billp',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('103','mpostma',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('104','cchmielewski',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('105','madjali',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('106','tirwin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('107','danielt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('108','upirovan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','elibraro','127','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('109','rmarcoux',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('110','gtaboada',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','caio','40','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('111','jflory',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('112','srockwell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('113','sporter',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('114','brhayes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('115','cheong','cheong@juniper.net','Alex','Cheong','5729de9d19f03fb167edc598f9f657b3','sfoong','1','1','2011-10-12');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('116','mcates',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('117','jschwegel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('118','jwarner',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('119','vance',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Iquinn','121','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('120','cfrain',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('121','dmilligan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('122','odpoveda',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('123','ilaky',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('124','guya',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('125','abury',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','egagala','24','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('126','rdamon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('127','dasmolov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('128','sknight',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('129','egagala',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('130','rdjohnson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('131','rsprouse',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmccombe','47','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('132','jschweisthal',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('133','mchiandusso',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('134','jaimec',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fberrueta','126','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('135','smendels',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('136','fischbach',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('137','jeffreys',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('138','jkoser',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('139','khendrych',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('140','jkihn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','RPROULX','31','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('141','jdegrace',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('142','bkine',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('143','BSimon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('144','zchen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('145','smentzer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('146','rdickens',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('147','sbeveridge',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmickey','28','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('148','golivieri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('149','anaik',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('150','adamg',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('151','tritchie',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('152','ron',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('153','jlabrecque',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('154','jtwilson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('155','wmollyhorn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('156','ttufo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('157','cmahoney',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('158','ajmccarthy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('159','abirjandi','abirjandi@juniper.net','Amir','Birjandi','1403301a5cce4b5c802bd23cda0d09ed','cucinell','136','1','2011-10-14');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('160','mharman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('161','rpatin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('162','pwilkens',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('163','gmaxwell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('164','rguancione',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rakhanna','76','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('165','bhendryx',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','eteece','49','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('166','baide',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('167','pleet',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bhaynes','116','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('168','rloureiro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('169','linhunt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('170','phamel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('171','knakashima',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alan','129','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('172','dmorrissette',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('173','gpek',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('174','ecano',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('175','mmcspedon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('176','mmokos',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('177','ricardod',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('178','dchad',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jframe','79','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('179','dmcginniss',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('180','danilor',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('181','jcostomiris',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('182','dstone',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','eteece','49','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('183','bohalloran',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('184','jstafford',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swilliam','41','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('185','bfedak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','glousteau','21','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('186','mriemer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('187','wbrassem',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('188','sraymond',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('189','cberger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('190','ekarnicki',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('191','mltolliver',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','MLTolliver','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('192','rrose',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('193','mparent',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('194','rmickey',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('195','cbowers',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('196','bgraham',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('197','lhemauer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('198','jayw',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dleitzel','17','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('199','cantrim',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('200','ltabenkin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kevwal','30','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('201','llorenzin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kevwal','30','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('202','cmessina',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('203','alarosa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('204','msmihula',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('205','amathur',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('206','cwhyte',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('207','jgrizzuti',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jaimec','25','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('208','mfearnow',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('209','barnys',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmccombe','47','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('210','mweiss',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('211','kevwal',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmccombe','47','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('212','mmcguirl',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('213','alapins',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('214','rproulx',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('215','wcook',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('216','kelvin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('217','djamison',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('218','jjlucas',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fraimon','67','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('219','alexzeng',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','szhao','23','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('220','deepinder',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('221','zhangwei',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('222','kdraper',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmccombe','47','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('223','mcornejo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jantich','97','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('224','srichardson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('225','jrolfe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kevwal','30','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('226','diffendal',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('227','sili',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('228','pmcnurlan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('229','xfzhou',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('230','dowang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('231','agoetz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('232','mfiorilli',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('233','rherr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('234','wwen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('235','pache',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('236','lserrano',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('237','marodriguez',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('238','cbisson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fraimon','67','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('239','vabramov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('240','marianoy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('241','Bnelson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rdickens','26','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('242','pcoveney',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('243','jtaylor',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('244','dwheeler',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('245','mferratt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mason','117','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('246','murray',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('247','mkuepper',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jframe','79','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('248','vkasacavage',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('249','rwilches',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('250','tokolowicz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('251','jmendel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('252','dchevrie',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('253','chavi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jantich','97','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('254','scardali',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('255','aserebryakov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('256','ghzhou',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('257','pvandijk',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('258','lkarantzios',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('259','troberts',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('260','lkye',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','szhao','23','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('261','bseifert',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rproulx','31','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('262','bmatthews',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('263','mmessina',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('264','kobbie',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('265','azmias',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ismail','6','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('266','caio',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('267','gbensimon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('268','jhadler',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mkremmel','43','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('269','swilliam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('270','mpereira',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('271','dgibson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('272','spraay',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('273','erandle',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('274','mkremmel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('275','mspagnolo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('276','gcoldwells',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('277','mbergt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('278','jring',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('279','beatty',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('280','kennywong',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','resigned','130','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('281','rshahab',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('282','cszhang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('283','wangsz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('284','djevans',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbowers','29','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('285','jgeorges','jgeorges@juniper.net','Jeremy ','Georges','819760c5e4efca34261b76ea24ed83ba','tacoma','20','1','2011-11-04');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('286','ericwen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('287','oliverxu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('288','agiovannini',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','caio','40','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('289','yjzhou',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('290','adesportes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('291','xpli',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('292','kdineen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tregonini','122','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('293','mploeg',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('294','danhnt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('295','acowling',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('296','pgeenens',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('297','liujun',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('298','oprokofiev',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('299','mwiget',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('300','cgraf',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('301','kernst',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('302','hmetschulat',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('303','fsteingass',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Wolfgang','112','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('304','wmlootfun',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('305','gschwart',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('306','mpopov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('307','rpope',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpope','128','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('308','kstokkel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('309','tbeaumont',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','eteece','49','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('310','spalislamovic',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('311','rbooth',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('312','nhenriksson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('313','jburns',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('314','pkofoid',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','eteece','49','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('315','gbokas',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('316','jwparks',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('317','weden',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','beden','132','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('318','lscott',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tcampbell','109','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('319','ploenberg',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('320','kmeier',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('321','mpieklik',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tcampbell','109','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('322','dgam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('323','thathawa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('324','jhutcheson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('325','joshual',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('326','bdarr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('327','evalderhaug',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('328','tleffingwell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('329','jixj',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('330','truban',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('331','jmccombe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('332','rayr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('333','eteece',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('334','rpalmer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('335','sreichmeider',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('336','padmak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('337','ddivins',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('338','zelbanna',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('339','ajuter',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('340','cdierks',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('341','jullgren',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('342','jwall',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('343','awallerman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('344','polsson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('345','aosada',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('346','worawit',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('347','thanakorn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('348','paanob',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('349','ibam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('350','irzan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('351','deny',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('352','abalnicki',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('353','lguess',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jeremy','60','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('354','pgerry',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Lguess','54','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('355','oschuermann',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('356','jhawk',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('357','vtavares',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('358','lemaster',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('359','jeremy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('360','bwallace',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('361','evasilenko',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('362','malbers',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('363','mleonard',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('364','cyoung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('365','dbackman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('366','ssteven','ssteven@juniper.net','Stewart','Steven','bdb6475e866807f5fcc1f19a24e7fe08','arowley','90','1','2011-10-13');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('367','pbrickner',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('368','mhudson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('369','twollschlaeger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wolfgang','112','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('370','ccall',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('371','bflament',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('372','rwanders',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('373','regonini',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('374','abulletti',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('375','akhileshv',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('376','ksakamoto',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('377','mpergament',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('378','tkolb',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('379','thenning',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('380','sugawara',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('381','adoehn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('382','ksator',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('383','jwalz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('384','ewaxvik',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swilliam','41','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('385','tzieger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('386','jseitz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('387','fraimon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('388','rmurrell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('389','bgage',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('390','bpavane',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('391','rmudd',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lemaster','59','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('392','gbunt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','temp_mgr','72','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('393','cklam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','temp_mgr','72','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('394','temp_mgr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('395','mlangdon','mlangdon@juniper.net','Michael','Langdon','1f7f8e99cacf6ac6156a8c6c7a27e8d6','jmaxfiel','123','1','2011-10-11');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('396','aball',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('397','tomv',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lemaster','59','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('398','rakhanna',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('399','mcao',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rakhanna','76','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('400','okupke',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','gweltmaier','115','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('401','ewatts',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('402','markku',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('403','jmolero',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('404','eater',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('405','tgshahrizam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ismail','6','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('406','fhirji',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dlindner','78','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('407','pvanoene',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('408','jdeabreu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('409','cconklin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('410','sjmartin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('411','jwoods',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('412','rgrimes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Kdineen','44','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('413','wtavernier',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('414','honishi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sugawara','65','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('415','dlindner',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('416','jframe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('417','kshea',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('418','hschroeder',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pcutilla','133','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('419','geaton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('420','mpratt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('421','aaron',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('422','ggruber',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','gweltmaier','115','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('423','tcalarco',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('424','gkorrub',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('425','djjohnson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rdickens','26','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('426','passimon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('427','dcharef',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('428','asibout',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('429','kpmiller',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('430','dkearley',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('431','ygheerolfs',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('432','estoia',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('433','jfcouturier',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('434','cgillis',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('435','standa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kwatanabe','125','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('436','lpaumelle',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('437','vmukhin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('438','mshaath',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('439','slager',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('440','ymughrabi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('441','hekarhani',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('442','aaltawil',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('443','msubhi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('444','rwedderburn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('445','kwaheed',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('446','dcrompton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('447','shamdash',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('448','rli',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('449','lenny',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('450','aminakov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('451','jlperez',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('452','semam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('453','ikhan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('454','raghu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('455','vleonov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('456','ricardo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('457','kboules',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('458','takayuki',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhomma','84','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('459','kkawana',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhomma','84','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('460','zkhan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('461','mourachi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tmori','114','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('462','hikubota',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhomma','84','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('463','ykunikata',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('464','tsuyoshi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('465','kurose',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tsuyoshi','81','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('466','sinoue',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('467','yutaka',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kobbie','39','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('468','scrocker',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('469','nhomma',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('470','aomer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('471','hkataoka',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('472','hkaneko',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('473','nnagatak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('474','katagiri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('475','sonose',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('476','nshirai',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('477','ddeleest',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('478','fomari',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('479','sfr','sfr@juniper.net','Scott','Robohn','853df2a6c52600dfe301d7d02a724483','rayr','122','1','2011-11-03');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('480','slabakov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('481','dshokarev',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('482','salnajdawi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('483','mpilotto',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jaimec','25','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('484','obachour',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('485','btatsu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('486','kshige',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('487','hkitagawa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('488','parkmi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('489','nburke',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','scrocker','83','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('490','ksaito',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tsuyoshi','81','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('491','dayan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('492','uwe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('493','nsiebelink',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('494','akennedy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('495','nelliot',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('496','brawle',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('497','arowley','arowley@juniper.net','Adrian','Rowley','b2cf82019afab554364bd0f8626730ef','scrocker','135','1','2011-10-10');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('498','csmith',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmatthews','98','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('499','abays',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','scrocker','83','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('500','trich','trich@juniper.net','Trichy','Raman','488b35b253ada81c53f1be3bb4f04973','arowley','90','1','2011-10-25');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('501','paulo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('502','smckinnon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','scrocker','83','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('503','joself',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('504','juze',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('505','jmcguire',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('506','aharker',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('507','esicard',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','juze','91','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('508','fpalozza',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','juze','91','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('509','gtate',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('510','acrampton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('511','fbellini',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('512','tabbas',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('513','komiyama',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('514','jscramuzzo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('515','kkunioka',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('516','jantich',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','juze','91','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('517','rdalbenzio',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('518','xhoms',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jantich','97','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('519','sbergset','sbergset@juniper.net','Shaun','Bergset','8dd191e2f267e5c7f1df4805d398d391','mmatthews','98','1','2011-10-18');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('520','lmori',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('521','mmatthews','mmatthews@juniper.net','Martin','Matthews','3bf54fc7ca78a3d45e867968016fa026','scrocker','135','1','2011-10-10');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('522','mvaliji',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('523','ntduc',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('524','stevens',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('525','mrausche',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('526','asalesi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','chrism','120','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('527','ecowart',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lemaster','59','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('528','rfjaeger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lemaster','59','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('529','bsalamone',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('530','cucinell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Regonini','63','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('531','bagueh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','regonini','63','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('532','gtheodorak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('533','woyoung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('534','alew',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','regonini','63','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('535','kshimazu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tsuyoshi','81','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('536','mmelloul',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('537','omelwig',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Juze','91','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('538','dspillane',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','scrocker','83','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('539','hsugano',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('540','jfujimiya',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('541','tkitamura',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('542','mdelre',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('543','acooley','acooley@juniper.net','adam','cooley','6eb58ac78df2450f752bf868dfb9eca9','rdickens','135','1','2011-10-14');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('544','ddemers',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('545','eparra',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('546','ttoth',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('547','joakim',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('548','jarimura',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('549','ynishika',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('550','dshimo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('551','kanzai',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('552','kwilliams',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('553','bgriffin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('554','jhorton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tcampbell','109','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('555','kodachi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('556','mpuras',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('557','tcampbell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('558','rogrady',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('559','rmcgovern',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('560','mschofield',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('561','kwmiller',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','glousteau','21','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('562','je',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('563','eward',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('564','alupher',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('565','rafern',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurell','131','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('566','ddurant',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('567','agilliam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbowers','29','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('568','bsprague',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbowers','29','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('569','tyanagih',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sugawara','65','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('570','seiichi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kwatanabe','125','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('571','ssuzuki',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('572','uklatt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('573','wolfgang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('574','namikawa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhomma','84','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('575','mnaitoh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('576','nakagawa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kobbie','39','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('577','ito',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('578','tmori',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('579','bosco',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','szhao','23','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('580','hwma',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','zhanglong','12','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('581','lmcao',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('582','thamdani',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('583','jtatham',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('584','erwinn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('585','ssandhu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('586','seyler',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('587','adash',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('588','murugank',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('589','niharp',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('590','sajmeri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('591','tschmidt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('592','nitinvig',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('593','dnelson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('594','gweltmaier',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('595','inightingale','inightingale@juniper.net','Ian','Nightingale','b014fa995eeeee081e3d87a5b6413039','arowley','90','1','2011-10-14');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('596','tgraw',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmessina','38','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('597','dpagliuca',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('598','tzack',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('599','ibrana',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('600','earies',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('601','stevenb',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('602','sholman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('603','ehall',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','glousteau','21','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('604','dmauro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('605','cconte',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','psmiraglia','18','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('606','dhanks',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('607','mputala',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('608','amaerz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wolfgang','112','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('609','hviertel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wolfgang','112','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('610','rtempleton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('611','habib',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('612','whalim',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('613','dharp',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('614','bsahin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('615','ilateef','ilateef@juniper.net','Irfan','Lateef','04414e29ca851fc0893bb4c8a7880804','psmiraglia','136','1','2011-10-11');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('616','yfuentes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('617','jdschmidt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('618','skobayas',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('619','takamasa','takamasa@juniper.net','Takamasa','Suzuki','34cff99555bfc257fef13f433aff4f78','sfoong','1','1','2011-11-08');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('620','stevenba',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sfoong','1','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('621','stgreen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('622','jojames','jojames@juniper.net','Jo','James','a5ce208e16492a703004a6b48896c135','arowley','90','1','2011-10-11');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('623','justinh','justinh@juniper.net','Justin','Harris','eea92ddb5477d416953875c65c6e1c01','arowley','90','1','2011-10-24');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('624','pnellipudi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','psmiraglia','18','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('625','creneau',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('626','jclarke','jclarke@juniper.net','Justin','Clarke','62c4303f14cd2c9be4ef6f670f7e960f','arowley','90','1','2011-10-11');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('627','wvanderelst',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('628','kjamali',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Tabbas','95','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('629','bprakash',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('630','csummers',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('631','jripatti',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhenriksson','45','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('632','twessels',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('633','sferguson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfield','123','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('634','muzamilk',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('635','zpatel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('636','jkretzing',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('637','dzook',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Tacoma','20','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('638','udhiyan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('639','dnoble',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dspillane','106','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('640','kparalkar',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('641','mnarayanan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('642','sgonzales',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('643','sphoffman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('644','smaryland',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rproulx','31','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('645','ytada',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('646','tmatsuda',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('647','ddeville',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('648','andyl',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('649','churt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rdickens','26','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('650','drivera',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('651','acleung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rakhanna','76','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('652','aldasilva',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('653','malexander',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rproulx','31','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('654','mfurby',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dspillane','106','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('655','martine',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wolfgang','112','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('656','nam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('657','jryburn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('658','mbankey',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Rmudd','71','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('659','zjx',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('660','zhiang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('661','eyoung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('662','ameisinger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Wolfgang','112','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('663','ryand',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tacoma','20','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('664','wenting',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('665','emenor',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('666','lionchen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('667','gzekri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('668','steveliu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan','2','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('669','kkawashi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('670','leroyf',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('671','jdoshi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('672','nmarcoux',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('673','dgarros',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('674','aharaguchi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('675','gspolidoro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('676','mamato',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('677','aguzhevskiy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('678','fverduyckt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('679','mstandage',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16',NULL,'98','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('680','sgalmozzi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('681','jcarvallo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('682','mpensler',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('683','apokrovskaya',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('684','jeboule',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('685','cmunday',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('686','rkleung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('687','cgist',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmickey','28','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('688','tzaveri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('689','mkanumuru',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('690','rjwright',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16',NULL,'98','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('691','randyzh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('692','terryc',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('693','mderriennic',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('694','hviehweger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('695','bhaynes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('696','mason',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('697','Slafuria',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('699','chrism',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('700','Iquinn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('701','tregonini',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('702','jmaxfield',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('703','ktank',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('704','kwatanabe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('705','fberrueta',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('706','elibraro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('707','bpope',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('708','alan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('709','resigned',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('710','rmurell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('711','beden',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('712','pcutilla',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('713','ycheng',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('714','stclair','stclair@biggiesize.com','Chris','St. Clair','4c3ee0195f2444ad204ccd7d94cb6d16',NULL,'135','1','2011-10-10');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('715','cwrightson','cwrightson@juniper.net','Colin','Wrightson','c8108df8eaad2bf5004850ab32c9fa23',NULL,'90','1','2011-10-26');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('717','foobar','foo@bar.com','Foo','Bar','3858f62230ac3c915f300c664312c63f',NULL,'140','1','2011-10-11');
INSERT INTO `users` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('718','dfusse','dfusse@juniper.net','Dario','Fusse','facb1fe43fe738d6270fc93c5926d06f',NULL,'40','1','2011-10-17');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


--
-- Create Table `usersTmp`
--

DROP TABLE IF EXISTS `usersTmp`;
CREATE TABLE `usersTmp` (
  `users_id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `password` char(32) NOT NULL DEFAULT '4c3ee0195f2444ad204ccd7d94cb6d16',
  `mgr` varchar(16) DEFAULT NULL COMMENT 'This field is for historical purposes and will be deprecated.',
  `managers_id` int(11) DEFAULT NULL,
  `hasProfile` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Has the user defined a profile yet?',
  `passwordChange` date DEFAULT NULL,
  PRIMARY KEY (`users_id`),
  UNIQUE KEY `userName` (`userName`),
  KEY `mgr` (`mgr`),
  KEY `managers_id` (`managers_id`),
  CONSTRAINT `userstmp_ibfk_1` FOREIGN KEY (`managers_id`) REFERENCES `managers` (`managers_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=718 DEFAULT CHARSET=latin1;

--
-- Data for Table `usersTmp`
--

/*!40000 ALTER TABLE `usersTmp` DISABLE KEYS */;
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('1','kuangbin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16',NULL,NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('2','atham',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sfoong','1','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('3','sfoong','sfoong@juniper.net','Sui Jin','Foong','d8578edf8458ce06fbc5bb76a58c5ca4',NULL,'80','1','2011-10-10');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('4','wchan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('5','mkohno',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('6','hidet',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('7','bayliss',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mkolon','3','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('8','ALeung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sfoong','1','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('9','kkan','kkan@juniper.net','Kondia','Kan','9fd1ead68c0329f5332d744a1524413c','sfoong','1','1','2011-10-13');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('10','harryt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('11','henrycheung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('12','echoi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('13','atong',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('14','mchen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('15','srho',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('16','mkolon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('17','sstevens','sstevens@juniper.net','Scott','Stevens','8fb2ee7c013b1ec54d1a86043c88b84c','admin','5','1','2011-10-09');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('18','admin','admin_setimetracker@noreply.com','Admin','User','e584c11797347c15adb087a5c30e34e3',NULL,NULL,'1','2011-10-13');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('19','krajesh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('20','aaronchan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ismail','6','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('21','rohits',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('22','amandhar',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('23','pbose',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('24','dane',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('25','ingack',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bkim','11','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('26','bpchoi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bkim','11','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('27','htxu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','zhanglong','12','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('28','hlyeo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('29','zhuolin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Zhanglong','12','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('30','ismail',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('31','indrajaya',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('32','mdoan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','resigned','130','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('33','tnagy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('34','jatkins',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('35','fprowse',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('36','jpost','jpost@juniper.net','Jim','Post','8fb2ee7c013b1ec54d1a86043c88b84c','sstevens',NULL,'1','2011-10-07');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('37','subrar',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('38','sandeeps',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('39','alvin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('40','mmiller',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('41','bkim',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('42','zhanglong',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('43','wwang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('44','ipalmer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('45','naveenar',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('46','aliang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','zhanglong','12','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('47','bhutson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sfoong','1','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('48','swoods',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('49','bisham',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('50','jpsingh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('51','msee',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ycheng','134','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('52','jmaxfiel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('53','zeskiocak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('54','hamish',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('55','jnavarro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','caio','40','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('56','dcsonka',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('57','shannon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('58','twang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('59','jackycj',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','twang','16','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('60','changyu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','szhao','23','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('61','wtian',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','twang','16','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('62','yzhi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','twang','16','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('63','markanderson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbowers','29','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('64','shawn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lwang','19','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('65','yuxin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lwang','19','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('66','anorton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kevwal','30','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('67','brent',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bhaynes','116','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('68','dleitzel','dleitzel@juniper.net','David','Leitzel','2fad3cd8a9bde4d946555997d0f5d755','jmccombe','136','1','2011-10-13');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('69','simonmao',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Twang','16','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('70','azrahia',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('71','psmiraglia',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','regonini','63','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('72','liuj',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lwang','19','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('73','lwang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('74','pkedra',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('75','tacoma',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('76','rwhitney',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('77','pzablotski',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Slafuria','118','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('78','gfecteau',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Cucinell','102','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('79','mike',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('80','gguay',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('81','mccarthy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('82','glousteau',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('83','marco',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('84','jcoppock',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('85','tonyzeng',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','zhanglong','12','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('86','lfeinbaum',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('87','lisp',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('88','chenjiang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('89','hadlley',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('90','rpasco',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('91','sbrown',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('92','dspesard',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('93','jayd',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('94','djl',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('95','gshen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lwang','19','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('96','jasonli',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('97','mshamjee',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('98','sujit',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sandeeps','8','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('99','yeht',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('100','szhao',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('101','josephk',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('102','billp',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('103','mpostma',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('104','cchmielewski',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('105','madjali',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('106','tirwin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('107','danielt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('108','upirovan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','elibraro','127','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('109','rmarcoux',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('110','gtaboada',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','caio','40','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('111','jflory',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('112','srockwell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('113','sporter',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('114','brhayes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('115','cheong','cheong@juniper.net','Alex','Cheong','5729de9d19f03fb167edc598f9f657b3','sfoong','1','1','2011-10-12');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('116','mcates',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('117','jschwegel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('118','jwarner',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('119','vance',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Iquinn','121','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('120','cfrain',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('121','dmilligan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('122','odpoveda',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('123','ilaky',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('124','guya',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('125','abury',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','egagala','24','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('126','rdamon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('127','dasmolov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('128','sknight',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('129','egagala',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('130','rdjohnson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('131','rsprouse',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmccombe','47','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('132','jschweisthal',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('133','mchiandusso',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('134','jaimec',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fberrueta','126','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('135','smendels',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('136','fischbach',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('137','jeffreys',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('138','jkoser',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('139','khendrych',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('140','jkihn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','RPROULX','31','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('141','jdegrace',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('142','bkine',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('143','BSimon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('144','zchen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('145','smentzer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('146','rdickens',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('147','sbeveridge',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmickey','28','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('148','golivieri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('149','anaik',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('150','adamg',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('151','tritchie',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('152','ron',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('153','jlabrecque',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bgage','69','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('154','jtwilson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('155','wmollyhorn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('156','ttufo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('157','cmahoney',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('158','ajmccarthy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('159','abirjandi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('160','mharman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('161','rpatin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('162','pwilkens',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('163','gmaxwell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('164','rguancione',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rakhanna','76','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('165','bhendryx',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','eteece','49','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('166','baide',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('167','pleet',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bhaynes','116','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('168','rloureiro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('169','linhunt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('170','phamel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('171','knakashima',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alan','129','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('172','dmorrissette',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('173','gpek',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('174','ecano',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('175','mmcspedon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('176','mmokos',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('177','ricardod',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('178','dchad',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jframe','79','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('179','dmcginniss',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('180','danilor',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('181','jcostomiris',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('182','dstone',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','eteece','49','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('183','bohalloran',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('184','jstafford',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swilliam','41','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('185','bfedak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','glousteau','21','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('186','mriemer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('187','wbrassem',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('188','sraymond',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('189','cberger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('190','ekarnicki',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('191','mltolliver',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','MLTolliver',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('192','rrose',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('193','mparent',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('194','rmickey',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('195','cbowers',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('196','bgraham',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('197','lhemauer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('198','jayw',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dleitzel','17','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('199','cantrim',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('200','ltabenkin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kevwal','30','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('201','llorenzin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kevwal','30','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('202','cmessina',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('203','alarosa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('204','msmihula',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('205','amathur',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('206','cwhyte',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('207','jgrizzuti',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jaimec','25','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('208','mfearnow',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('209','barnys',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmccombe','47','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('210','mweiss',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('211','kevwal',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmccombe','47','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('212','mmcguirl',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('213','alapins',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('214','rproulx',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('215','wcook',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('216','kelvin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('217','djamison',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('218','jjlucas',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fraimon','67','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('219','alexzeng',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','szhao','23','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('220','deepinder',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('221','zhangwei',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('222','kdraper',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmccombe','47','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('223','mcornejo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jantich','97','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('224','srichardson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('225','jrolfe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kevwal','30','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('226','diffendal',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('227','sili',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('228','pmcnurlan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('229','xfzhou',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('230','dowang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('231','agoetz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('232','mfiorilli',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('233','rherr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('234','wwen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwang','13','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('235','pache',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('236','lserrano',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('237','marodriguez',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('238','cbisson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fraimon','67','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('239','vabramov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('240','marianoy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('241','Bnelson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rdickens','26','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('242','pcoveney',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('243','jtaylor',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('244','dwheeler',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('245','mferratt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mason','117','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('246','murray',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('247','mkuepper',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jframe','79','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('248','vkasacavage',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('249','rwilches',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('250','tokolowicz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('251','jmendel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('252','dchevrie',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('253','chavi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jantich','97','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('254','scardali',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('255','aserebryakov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('256','ghzhou',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('257','pvandijk',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('258','lkarantzios',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('259','troberts',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('260','lkye',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','szhao','23','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('261','bseifert',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rproulx','31','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('262','bmatthews',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('263','mmessina',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('264','kobbie',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('265','azmias',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ismail','6','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('266','caio',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jdeabreu','77','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('267','gbensimon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('268','jhadler',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mkremmel','43','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('269','swilliam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('270','mpereira',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('271','dgibson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('272','spraay',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('273','erandle',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('274','mkremmel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('275','mspagnolo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('276','gcoldwells',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('277','mbergt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('278','jring',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('279','beatty',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('280','kennywong',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','resigned','130','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('281','rshahab',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('282','cszhang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('283','wangsz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('284','djevans',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbowers','29','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('285','jgeorges',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tacoma','20','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('286','ericwen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('287','oliverxu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('288','agiovannini',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','caio','40','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('289','yjzhou',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('290','adesportes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('291','xpli',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('292','kdineen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tregonini','122','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('293','mploeg',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('294','danhnt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('295','acowling',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('296','pgeenens',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('297','liujun',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('298','oprokofiev',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('299','mwiget',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('300','cgraf',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('301','kernst',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('302','hmetschulat',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('303','fsteingass',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Wolfgang','112','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('304','wmlootfun',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('305','gschwart',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('306','mpopov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('307','rpope',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpope','128','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('308','kstokkel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('309','tbeaumont',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','eteece','49','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('310','spalislamovic',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('311','rbooth',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','erandle','42','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('312','nhenriksson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('313','jburns',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('314','pkofoid',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','eteece','49','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('315','gbokas',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('316','jwparks',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('317','weden',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','beden','132','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('318','lscott',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tcampbell','109','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('319','ploenberg',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('320','kmeier',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('321','mpieklik',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tcampbell','109','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('322','dgam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('323','thathawa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('324','jhutcheson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('325','joshual',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('326','bdarr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('327','evalderhaug',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('328','tleffingwell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('329','jixj',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('330','truban',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('331','jmccombe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('332','rayr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('333','eteece',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('334','rpalmer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('335','sreichmeider',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rogrady','110','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('336','padmak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ecowart','100','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('337','ddivins',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('338','zelbanna',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('339','ajuter',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('340','cdierks',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('341','jullgren',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('342','jwall',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('343','awallerman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('344','polsson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('345','aosada',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('346','worawit',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('347','thanakorn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('348','paanob',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('349','ibam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('350','irzan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('351','deny',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('352','abalnicki',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('353','lguess',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jeremy','60','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('354','pgerry',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Lguess','54','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('355','oschuermann',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('356','jhawk',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('357','vtavares',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('358','lemaster',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('359','jeremy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('360','bwallace',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('361','evasilenko',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('362','malbers',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('363','mleonard',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('364','cyoung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('365','dbackman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('366','ssteven','ssteven@juniper.net','Stewart','Steven','bdb6475e866807f5fcc1f19a24e7fe08','arowley','90','1','2011-10-13');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('367','pbrickner',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('368','mhudson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('369','twollschlaeger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wolfgang','112','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('370','ccall',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('371','bflament',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('372','rwanders',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('373','regonini',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('374','abulletti',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('375','akhileshv',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('376','ksakamoto',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('377','mpergament',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('378','tkolb',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('379','thenning',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('380','sugawara',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('381','adoehn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('382','ksator',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('383','jwalz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('384','ewaxvik',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swilliam','41','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('385','tzieger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('386','jseitz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('387','fraimon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('388','rmurrell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('389','bgage',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','slafuria','118','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('390','bpavane',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pgerry','55','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('391','rmudd',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lemaster','59','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('392','gbunt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','temp_mgr','72','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('393','cklam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','temp_mgr','72','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('394','temp_mgr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('395','mlangdon','mlangdon@juniper.net','Michael','Langdon','1f7f8e99cacf6ac6156a8c6c7a27e8d6','jmaxfiel','123','1','2011-10-11');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('396','aball',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('397','tomv',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lemaster','59','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('398','rakhanna',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfiel','15','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('399','mcao',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rakhanna','76','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('400','okupke',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','gweltmaier','115','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('401','ewatts',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('402','markku',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('403','jmolero',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('404','eater',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('405','tgshahrizam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ismail','6','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('406','fhirji',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dlindner','78','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('407','pvanoene',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('408','jdeabreu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('409','cconklin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('410','sjmartin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('411','jwoods',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('412','rgrimes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Kdineen','44','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('413','wtavernier',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('414','honishi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sugawara','65','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('415','dlindner',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('416','jframe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('417','kshea',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('418','hschroeder',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pcutilla','133','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('419','geaton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('420','mpratt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('421','aaron',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('422','ggruber',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','gweltmaier','115','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('423','tcalarco',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('424','gkorrub',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('425','djjohnson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rdickens','26','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('426','passimon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('427','dcharef',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('428','asibout',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('429','kpmiller',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('430','dkearley',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bpavane','70','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('431','ygheerolfs',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('432','estoia',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jscramuzzo','96','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('433','jfcouturier',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('434','cgillis',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('435','standa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kwatanabe','125','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('436','lpaumelle',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('437','vmukhin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('438','mshaath',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('439','slager',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('440','ymughrabi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('441','hekarhani',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('442','aaltawil',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('443','msubhi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('444','rwedderburn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('445','kwaheed',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('446','dcrompton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('447','shamdash',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('448','rli',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('449','lenny',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cucinell','102','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('450','aminakov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('451','jlperez',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('452','semam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('453','ikhan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('454','raghu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sstevens','4','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('455','vleonov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('456','ricardo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('457','kboules',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('458','takayuki',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhomma','84','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('459','kkawana',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhomma','84','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('460','zkhan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('461','mourachi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tmori','114','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('462','hikubota',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhomma','84','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('463','ykunikata',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('464','tsuyoshi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('465','kurose',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tsuyoshi','81','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('466','sinoue',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('467','yutaka',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kobbie','39','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('468','scrocker',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('469','nhomma',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('470','aomer',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('471','hkataoka',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('472','hkaneko',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('473','nnagatak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('474','katagiri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('475','sonose',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('476','nshirai',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('477','ddeleest',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('478','fomari',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('479','sfr',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rayr','48','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('480','slabakov',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('481','dshokarev',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('482','salnajdawi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('483','mpilotto',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jaimec','25','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('484','obachour',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('485','btatsu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('486','kshige',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('487','hkitagawa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('488','parkmi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('489','nburke',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','scrocker','83','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('490','ksaito',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tsuyoshi','81','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('491','dayan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('492','uwe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('493','nsiebelink',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('494','akennedy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('495','nelliot',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('496','brawle',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('497','arowley','arowley@juniper.net','Adrian','Rowley','b2cf82019afab554364bd0f8626730ef','scrocker','135','1','2011-10-10');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('498','csmith',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmatthews','98','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('499','abays',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','scrocker','83','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('500','trich',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('501','paulo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('502','smckinnon',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','scrocker','83','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('503','joself',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('504','juze',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('505','jmcguire',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('506','aharker',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('507','esicard',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','juze','91','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('508','fpalozza',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','juze','91','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('509','gtate',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('510','acrampton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('511','fbellini',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('512','tabbas',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('513','komiyama',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('514','jscramuzzo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jhawk','57','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('515','kkunioka',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('516','jantich',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','juze','91','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('517','rdalbenzio',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('518','xhoms',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jantich','97','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('519','sbergset',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmatthews','98','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('520','lmori',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('521','mmatthews','mmatthews@juniper.net','Martin','Matthews','3bf54fc7ca78a3d45e867968016fa026','scrocker','135','1','2011-10-10');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('522','mvaliji',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('523','ntduc',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('524','stevens',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('525','mrausche',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('526','asalesi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','chrism','120','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('527','ecowart',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lemaster','59','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('528','rfjaeger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lemaster','59','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('529','bsalamone',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('530','cucinell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Regonini','63','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('531','bagueh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','regonini','63','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('532','gtheodorak',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('533','woyoung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmiller','10','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('534','alew',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','regonini','63','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('535','kshimazu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tsuyoshi','81','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('536','mmelloul',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('537','omelwig',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Juze','91','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('538','dspillane',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','scrocker','83','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('539','hsugano',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('540','jfujimiya',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('541','tkitamura',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('542','mdelre',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('543','acooley',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rdickens','26','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('544','ddemers',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('545','eparra',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('546','ttoth',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','vtavares','58','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('547','joakim',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cdierks','52','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('548','jarimura',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kanzai','107','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('549','ynishika',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('550','dshimo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('551','kanzai',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('552','kwilliams',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('553','bgriffin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('554','jhorton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tcampbell','109','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('555','kodachi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('556','mpuras',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('557','tcampbell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','oschuermann','56','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('558','rogrady',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lguess','54','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('559','rmcgovern',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('560','mschofield',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('561','kwmiller',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','glousteau','21','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('562','je',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('563','eward',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('564','alupher',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tomv','75','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('565','rafern',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurell','131','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('566','ddurant',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','pbrickner','62','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('567','agilliam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbowers','29','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('568','bsprague',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbowers','29','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('569','tyanagih',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sugawara','65','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('570','seiichi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kwatanabe','125','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('571','ssuzuki',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('572','uklatt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','truban','46','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('573','wolfgang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('574','namikawa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhomma','84','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('575','mnaitoh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ito','113','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('576','nakagawa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','kobbie','39','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('577','ito',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('578','tmori',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('579','bosco',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','szhao','23','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('580','hwma',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','zhanglong','12','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('581','lmcao',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wwen','35','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('582','thamdani',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('583','jtatham',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('584','erwinn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('585','ssandhu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sreichmeider','51','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('586','seyler',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('587','adash',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('588','murugank',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('589','niharp',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('590','sajmeri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('591','tschmidt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('592','nitinvig',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('593','dnelson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','srichardson','33','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('594','gweltmaier',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uklatt','111','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('595','inightingale',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('596','tgraw',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmessina','38','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('597','dpagliuca',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('598','tzack',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','cbisson','36','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('599','ibrana',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('600','earies',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('601','stevenb',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mlangdon','73','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('602','sholman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('603','ehall',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','glousteau','21','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('604','dmauro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('605','cconte',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','psmiraglia','18','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('606','dhanks',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('607','mputala',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mrausche','99','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('608','amaerz',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wolfgang','112','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('609','hviertel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wolfgang','112','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('610','rtempleton',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('611','habib',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('612','whalim',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','obachour','86','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('613','dharp',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('614','bsahin',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','uwe','88','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('615','ilateef','ilateef@juniper.net','Irfan','Lateef','04414e29ca851fc0893bb4c8a7880804','psmiraglia','136','1','2011-10-11');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('616','yfuentes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('617','jdschmidt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mpuras','108','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('618','skobayas',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('619','takamasa',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sfoong','1','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('620','stevenba',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sfoong','1','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('621','stgreen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('622','jojames','jojames@juniper.net','Jo','James','a5ce208e16492a703004a6b48896c135','arowley','90','1','2011-10-11');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('623','justinh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','arowley','90','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('624','pnellipudi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','psmiraglia','18','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('625','creneau',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('626','jclarke','jclarke@juniper.net','Justin','Clarke','62c4303f14cd2c9be4ef6f670f7e960f','arowley','90','1','2011-10-11');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('627','wvanderelst',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('628','kjamali',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Tabbas','95','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('629','bprakash',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('630','csummers',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('631','jripatti',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nhenriksson','45','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('632','twessels',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aball','74','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('633','sferguson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmaxfield','123','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('634','muzamilk',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('635','zpatel',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('636','jkretzing',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmudd','71','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('637','dzook',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Tacoma','20','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('638','udhiyan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jmcguire','92','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('639','dnoble',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dspillane','106','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('640','kparalkar',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('641','mnarayanan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('642','sgonzales',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('643','sphoffman',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('644','smaryland',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rproulx','31','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('645','ytada',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ksakamoto','64','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('646','tmatsuda',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','aosada','53','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('647','ddeville',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmurrell','68','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('648','andyl',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dlindner','78','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('649','churt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rdickens','26','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('650','drivera',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rfjaeger','101','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('651','acleung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rakhanna','76','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('652','aldasilva',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','swoods','14','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('653','malexander',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rproulx','31','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('654','mfurby',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dspillane','106','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('655','martine',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wolfgang','112','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('656','nam',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alvin','9','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('657','jryburn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('658','mbankey',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Rmudd','71','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('659','zjx',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('660','zhiang',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','lisp','22','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('661','eyoung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','raghu','80','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('662','ameisinger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Wolfgang','112','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('663','ryand',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','tacoma','20','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('664','wenting',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','sinoue','82','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('665','emenor',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rpalmer','50','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('666','lionchen',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','Dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('667','gzekri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','omelwig','105','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('668','steveliu',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','wchan','2','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('669','kkawashi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nnagatak','85','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('670','leroyf',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('671','jdoshi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','subrar','7','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('672','nmarcoux',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('673','dgarros',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('674','aharaguchi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','alew','104','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('675','gspolidoro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('676','mamato',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','ktank','124','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('677','aguzhevskiy',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('678','fverduyckt',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nsiebelink','89','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('679','mstandage',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmathews',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('680','sgalmozzi',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','fpalozza','94','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('681','jcarvallo',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mcornejo','32','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('682','mpensler',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('683','apokrovskaya',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','evasilenko','61','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('684','jeboule',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('685','cmunday',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','nburke','87','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('686','rkleung',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('687','cgist',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','rmickey','28','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('688','tzaveri',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','troberts','37','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('689','mkanumuru',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','bagueh','103','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('690','rjwright',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','mmathews',NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('691','randyzh',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('692','terryc',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','dowang','34','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('693','mderriennic',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','esicard','93','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('694','hviehweger',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','jseitz','66','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('695','bhaynes',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('696','mason',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('697','Slafuria',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('699','chrism',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('700','Iquinn',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('701','tregonini',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('702','jmaxfield',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('703','ktank',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('704','kwatanabe',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('705','fberrueta',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('706','elibraro',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('707','bpope',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('708','alan',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('709','resigned',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('710','rmurell',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('711','beden',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('712','pcutilla',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('713','ycheng',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16','admin','5','0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('714','stclair','stclair@biggiesize.com','Chris','St. Clair','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'5','1','2011-10-10');
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('715','cwrightson',NULL,NULL,NULL,'4c3ee0195f2444ad204ccd7d94cb6d16',NULL,NULL,'0',NULL);
INSERT INTO `usersTmp` (`users_id`,`userName`,`email`,`firstName`,`lastName`,`password`,`mgr`,`managers_id`,`hasProfile`,`passwordChange`) VALUES ('717','foobar','foo@bar.com','Foo','Bar','3858f62230ac3c915f300c664312c63f',NULL,'135','1','2011-10-11');
/*!40000 ALTER TABLE `usersTmp` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

